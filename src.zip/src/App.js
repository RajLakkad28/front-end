import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HashRouter } from 'react-router-dom';
import Home from './component/Home';
import Login from './component/Login';
import SignUp from './component/SignUp';
import Event from './component/Event';
import Help from './component/Help';
import TermsOfService from './component/TermsOfService';
import PrivacyPolicy from './component/PrivacyPolicy';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import Profile from './component/Profile';


import CreateEvent from './component/CreateEvent';


function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/login" element={<Login />} />
        <Route path="/Event" element={<Event />} />
        <Route path="/CreateEvent" element={<CreateEvent />} />
        <Route path="/Signup" element={<SignUp />} />
        
        <Route path="/Help" element={<Help />} />
        <Route path="/TermsOfService" element={<TermsOfService /> } />
        <Route path="/PrivacyPolicy" element={<PrivacyPolicy /> } />
        <Route path="/Profile" element={<Profile />} /> 
      </Routes>
    </HashRouter>
  )
}

export default App;
