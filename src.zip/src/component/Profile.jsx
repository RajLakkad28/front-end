import React, { useState, useEffect } from 'react';
import {jwtDecode} from 'jwt-decode';
import { useNavigate } from 'react-router-dom';
import { FaUser, FaEnvelope, FaUserEdit, FaAddressCard, FaPhone } from 'react-icons/fa';
import './Profile.css'; // Import custom CSS

const Profile = () => {
    const [user, setUser] = useState(null);
    const [activity, setActivity] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            const decodedToken = jwtDecode(token);
            setUser({
                firstName: decodedToken.firstName,
                lastName: decodedToken.lastName,
                email: decodedToken.email,
                phone: decodedToken.phone,
                address: decodedToken.address
            });
            fetchUserActivity(decodedToken.userId); // Fetch user activity after decoding the token
        } else {
            navigate('/login');
        }
    }, [navigate]);

    const fetchUserActivity = async (userId) => {
        try {
            const response = await fetch(`/api/users/${userId}/activity`);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            setActivity(data);
        } catch (error) {
            console.error('Failed to fetch user activity:', error);
            // Handle error appropriately (e.g., set default values or show a message)
        }
    };

    if (!user) {
        return <div className="text-center">Loading...</div>;
    }

    return (
        <div className="container mt-5 profile-page">
            <div className="row">
                <div className="col-md-4">
                    <div className="card profile-card shadow-lg">
                        <div className="card-body text-center">
                            <h2 className="text-primary"><FaUser /> {`${user.firstName} ${user.lastName}`}</h2>
                            <p className="lead"><FaEnvelope /> {user.email}</p>
                            <p><FaPhone /> {user.phone}</p>
                            <p><FaAddressCard /> {user.address}</p>
                            <button className="btn btn-primary mt-3">
                                <FaUserEdit /> Edit Profile
                            </button>
                        </div>
                    </div>
                </div>
                <div className="col-md-8">
                    <div className="card shadow-lg">
                        <div className="card-header">
                            <h5>User Activity</h5>
                        </div>
                        <div className="card-body">
                            <p><strong>Last Login:</strong> {activity.lastLogin || 'N/A'}</p>
                            <p><strong>Account Created:</strong> {activity.accountCreated || 'N/A'}</p>
                            <p><strong>Upcoming Events:</strong> {activity.upcomingEvents || 0}</p>
                            <p><strong>Past Events:</strong> {activity.pastEvents || 0}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
