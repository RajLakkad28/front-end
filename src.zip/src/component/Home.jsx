import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';  // Import the Navbar component
import './Home.css';
import Footer from './Footer';
import axios from 'axios';
import './Loader.css';

const Home = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch events from the backend
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await axios.get('http://localhost:3001/api/events');
        setEvents(response.data);
        setLoading(false);
      } catch (err) {
        setError('Error fetching events. Please try again later.');
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  // Filter events based on the search query
  const filteredEvents = events.filter(event =>
    event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    event.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="full-loader-container">
        <div className="loader">
          <div className="loader-circle"></div>
        </div>
        <div className="loading-text">Loading events...</div>
      </div>
    );
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="container-fluid p-0">
      <Navbar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />  {/* Use the Navbar component */}
      <div className="hero-section">
        <div className="content">
          <h1>Event ticketing made simple</h1>
          <p>Start selling tickets in a few minutes</p>
          <button className="btn btn-success btn-lg">Create Event</button>
        </div>
      </div>
      <div className="container mt-5">
        <div className="row">
          {filteredEvents.map(event => (
            <div key={event._id} className="col-md-4 mb-4">
              <div className="card">
                <img src={event.imageUrl} className="card-img-top" alt={event.title} />
                <div className="card-body">
                  <h5 className="card-title">{event.title}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">{new Date(event.date).toLocaleDateString()}</h6>
                  <p className="card-text">{event.description}</p>
                  <p className="card-text "><strong>Location:</strong> {event.location}</p>
                  
                    <a href="#" className="btn btn-primary">Book Now</a>

                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Home;
